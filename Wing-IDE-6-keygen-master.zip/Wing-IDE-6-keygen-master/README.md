# Wing-IDE-6-keygen
Keygen for activation Wing IDE V6
# Use
```
$python keygen.py
```
#### Add ID
#### Copy Code Request of wing IDE 
#### Paste on code for activation on wing IDE
